package interfaces;

public interface interfaces {
    public void PrintJudul();
    public void HitungTambah();
    public void HitungKali();
}
